sudo php /var/www/html/cronjob.php
