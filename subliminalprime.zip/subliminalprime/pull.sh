#!/bin/sh
git pull --no-edit origin master