<?php
    echo strtolower(date("c"));
?>

